# Generated file - do not edit.
MINIMUM_PYMUPDF_VERSION = (1, 27, 1)
VERSION = '0.3.4'
