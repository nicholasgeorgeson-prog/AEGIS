"""
__main__.py.

This lets you run python -m proselint.
"""

from .command_line import main

if __name__ == "__main__":
    main()
