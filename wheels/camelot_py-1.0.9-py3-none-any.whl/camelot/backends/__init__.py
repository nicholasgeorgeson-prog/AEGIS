"""Camelot offers multiple backends to convert the PDFs to images so it can be analyzed by opencv."""

from .image_conversion import ImageConversionBackend
