from __future__ import annotations

from narwhals.testing.asserts.frame import assert_frame_equal
from narwhals.testing.asserts.series import assert_series_equal

__all__ = ("assert_frame_equal", "assert_series_equal")
