from __future__ import annotations

from narwhals.stable import v1

__all__ = ["v1"]
