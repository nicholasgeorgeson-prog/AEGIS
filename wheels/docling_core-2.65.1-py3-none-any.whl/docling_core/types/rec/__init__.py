"""Package for models defined by the Record type."""
