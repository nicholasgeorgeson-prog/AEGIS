"""
.. py:module:: segtok
   :synopsis: a sentence segmentation and word tokenization library

.. moduleauthor:: Florian Leitner <florian.leitner@gmail.com>
.. License: MIT <http://opensource.org/licenses/MIT>
"""
