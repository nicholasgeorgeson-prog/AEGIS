The data is the first 100 sentences from OSCAR unshuffled deduplicated en:

https://oscar-corpus.com/
