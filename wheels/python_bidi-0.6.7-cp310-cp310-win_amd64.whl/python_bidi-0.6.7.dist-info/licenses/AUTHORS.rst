=======
Credits
=======

Development Lead
----------------

* Meir Kriheli <mkriheli@gmail.com>

Tests
------

Tests based on fribidi_.

.. _fribidi: http://fribidi.org/

Contributors
------------

* Just van Rossum - https://github.com/justvanrossum
* Jakub Wilk <jwilk@jwilk.net>
* Christian Clauss <cclauss@me.com>
