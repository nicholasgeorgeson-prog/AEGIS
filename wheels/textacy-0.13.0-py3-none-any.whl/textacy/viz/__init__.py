from .network import draw_semantic_network
from .termite import draw_termite_plot

# TODO
# - interactive versions of all plots
